/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Client file
#include <iostream>
#include<string>
#include<cstring>
#include<fstream>
#include"menu.h"

using namespace std;

int main()
{
    Menu display;
    display.welcomeScreen();
    return EXIT_SUCCESS;
}


